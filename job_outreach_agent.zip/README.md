# Setup instructions for your outreach agent

1. Add your API keys to the `.env` file
2. Run `main.py` to trigger outreach
3. Customize modules in `/utils` as needed
