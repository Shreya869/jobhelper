# Entry point for manual trigger
