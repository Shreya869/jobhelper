# GPT prompt for outreach message
